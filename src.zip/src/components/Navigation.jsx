import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, Search, Heart, Menu, X, MapPin } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

export default function Navigation() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  const links = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/search', label: 'Zoeken', icon: Search },
    { to: '/favorites', label: 'Favorieten', icon: Heart },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-[var(--spacing-nav)] bg-white/95 backdrop-blur-md border-b border-border shadow-nav">
      <div className="h-full max-w-[1440px] mx-auto px-4 lg:px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 no-underline">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-ocean-500 to-ocean-600 flex items-center justify-center">
            <MapPin className="w-5 h-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold text-text leading-tight tracking-tight">
              Kas<span className="text-ocean-500">Korsou</span>
            </span>
            <span className="text-[10px] text-text-secondary leading-none tracking-wide uppercase">
              Real Estate Curaçao
            </span>
          </div>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-1">
          {links.map(({ to, label, icon: Icon }) => {
            const active = location.pathname === to
            return (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all no-underline
                  ${active
                    ? 'bg-ocean-50 text-ocean-600'
                    : 'text-text-secondary hover:text-text hover:bg-sand-200'
                  }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            )
          })}
        </div>

        {/* CTA + mobile toggle */}
        <div className="flex items-center gap-3">
          <Link
            to="/search"
            className="hidden sm:flex items-center gap-2 px-5 py-2.5 bg-ocean-500 text-white rounded-lg text-sm font-semibold hover:bg-ocean-600 transition-colors no-underline shadow-sm"
          >
            <Search className="w-4 h-4" />
            Woning zoeken
          </Link>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-sand-200 transition-colors"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden absolute top-[var(--spacing-nav)] left-0 right-0 bg-white border-b border-border shadow-lg"
          >
            <div className="p-4 flex flex-col gap-1">
              {links.map(({ to, label, icon: Icon }) => (
                <Link
                  key={to}
                  to={to}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-text-secondary hover:bg-sand-100 transition-colors no-underline"
                >
                  <Icon className="w-5 h-5" />
                  {label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
