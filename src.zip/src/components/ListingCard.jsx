import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Heart, Bed, Bath, Maximize, MapPin, ChevronLeft, ChevronRight } from 'lucide-react'
import { motion } from 'framer-motion'

function formatPrice(price) {
  return new Intl.NumberFormat('nl-NL', {
    style: 'currency',
    currency: 'ANG',
    maximumFractionDigits: 0,
  }).format(price)
}

export default function ListingCard({ listing, onFavorite, isFavorite }) {
  const [imgIndex, setImgIndex] = useState(0)
  const images = listing.images?.length > 0
    ? listing.images
    : ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&h=400&fit=crop']

  const nextImg = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setImgIndex((i) => (i + 1) % images.length)
  }
  const prevImg = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setImgIndex((i) => (i - 1 + images.length) % images.length)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group bg-white rounded-xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300"
    >
      <Link to={`/listing/${listing.id}`} className="block no-underline">
        {/* Image gallery */}
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={images[imgIndex]}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />

          {/* Navigation arrows */}
          {images.length > 1 && (
            <>
              <button
                onClick={prevImg}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center
                  opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-white"
              >
                <ChevronLeft className="w-4 h-4 text-text" />
              </button>
              <button
                onClick={nextImg}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center
                  opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-white"
              >
                <ChevronRight className="w-4 h-4 text-text" />
              </button>
            </>
          )}

          {/* Image dots */}
          {images.length > 1 && (
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
              {images.slice(0, 5).map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full transition-colors ${
                    i === imgIndex ? 'bg-white' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          )}

          {/* Favorite button */}
          <button
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              onFavorite?.(listing.id)
            }}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center
              hover:bg-white transition-colors shadow-sm"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${
                isFavorite ? 'fill-coral-400 text-coral-400' : 'text-text-secondary'
              }`}
            />
          </button>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-1.5">
            {listing.is_new && (
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-ocean-500 text-white rounded-md">
                Nieuw
              </span>
            )}
            {listing.is_featured && (
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-coral-400 text-white rounded-md">
                Uitgelicht
              </span>
            )}
            {listing.listing_type === 'rent' && (
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-sand-800 text-white rounded-md">
                Huur
              </span>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="text-base font-bold text-text leading-tight line-clamp-1">
              {listing.title}
            </h3>
          </div>

          <div className="flex items-center gap-1 mb-3">
            <MapPin className="w-3 h-3 text-ocean-500 shrink-0" />
            <span className="text-xs text-text-secondary truncate">
              {listing.neighborhood}{listing.address ? `, ${listing.address}` : ''}
            </span>
          </div>

          {/* Specs */}
          <div className="flex items-center gap-4 mb-3">
            {listing.bedrooms != null && (
              <div className="flex items-center gap-1">
                <Bed className="w-3.5 h-3.5 text-text-secondary" />
                <span className="text-xs text-text-secondary">{listing.bedrooms}</span>
              </div>
            )}
            {listing.bathrooms != null && (
              <div className="flex items-center gap-1">
                <Bath className="w-3.5 h-3.5 text-text-secondary" />
                <span className="text-xs text-text-secondary">{listing.bathrooms}</span>
              </div>
            )}
            {listing.area_sqm != null && (
              <div className="flex items-center gap-1">
                <Maximize className="w-3.5 h-3.5 text-text-secondary" />
                <span className="text-xs text-text-secondary">{listing.area_sqm} m²</span>
              </div>
            )}
          </div>

          {/* Price */}
          <div className="flex items-end justify-between">
            <p className="text-lg font-bold text-ocean-600">
              {formatPrice(listing.price)}
              {listing.listing_type === 'rent' && (
                <span className="text-xs font-normal text-text-secondary">/mnd</span>
              )}
            </p>
            <span className="text-[10px] text-text-secondary capitalize">
              {listing.property_type}
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  )
}
